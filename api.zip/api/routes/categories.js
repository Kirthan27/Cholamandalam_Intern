const router = require("express").Router();
const category = require("../models/category");

router.post("/",async(req,res)=>{
    console.log(req.body)
    const newCat = new category(req.body);
    try{
        const savedcat = await newCat.save();
        res.status(200).json(savedcat);
    }catch(err){
        res.status(500).json(err);
    }
});

router.get("/:id",async (req,res)=>{
        try{
                const cats = await category.findById(req.params.id);
                res.status(200).json(cats);
        }catch(err){
            res.status(500).json(err);
        }
});
module.exports = router;

router